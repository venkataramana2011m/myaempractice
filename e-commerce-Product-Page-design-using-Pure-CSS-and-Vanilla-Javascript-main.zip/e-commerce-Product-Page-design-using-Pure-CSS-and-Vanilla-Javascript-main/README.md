# Single e-commerce Product Page design using Pure CSS and Vanilla Javascript 
Single e-commerce product page design HTML, CSS and Vanilla Javascript. e-commerce product page with size and color selector option along with add to wish-list button. In this tutorial you can easily create a simple one page ecommerce product page.

#### YouTube Link: https://www.youtube.com/watch?v=WI7c9nt-WCk

#### ▶️  Subscribe Now: https://www.youtube.com/channel/UCUJ3zi-DTBZitHOOa4SJg3w?sub_confirmation=1

![thumblian](https://user-images.githubusercontent.com/98970815/183498326-10e6f4ab-3389-4b53-8e26-6ec862f360db.png)

------------------------------------------------------------------------


#### 📚 Resources: 

▶️ Google Fonts: https://fonts.google.com/
▶️ Boxicons: https://boxicons.com/

----------------------------------------------------------------------------
#### 🏷️ Tools used:

Editor: VS Code
Language: HTML, CSS, Javascript

----------------------------------------------------------------------------

