# AEMaaCS Commerce Add-On

This is the Commerce Add-On to be used with `AEMaaCS`
Install the `far` file correponding to the AEM instance type present alongside this README.

For more information visit [the official documentation](https://experienceleague.adobe.com/docs/experience-manager-cloud-service/content-and-commerce/home.html)
