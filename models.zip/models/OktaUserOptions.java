package com.ibm.commerce.core.models;

public class OktaUserOptions {
	private Boolean multiOptionalFactorEnroll;
	private Boolean warnBeforePasswordExpired;
	
	public Boolean getMultiOptionalFactorEnroll() {
		return multiOptionalFactorEnroll;
	}
	
	public void setMultiOptionalFactorEnroll(Boolean multiOptionalFactorEnroll) {
		this.multiOptionalFactorEnroll = multiOptionalFactorEnroll;
	}
	
	public Boolean getWarnBeforePasswordExpired() {
		return warnBeforePasswordExpired;
	}
	
	public void setWarnBeforePasswordExpired(Boolean warnBeforePasswordExpired) {
		this.warnBeforePasswordExpired = warnBeforePasswordExpired;
	}
}