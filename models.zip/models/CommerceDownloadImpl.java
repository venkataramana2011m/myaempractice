package com.ibm.commerce.core.models;

import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.adobe.cq.wcm.core.components.models.Download;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.dam.commons.util.UIHelper;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

@Model(adaptables = SlingHttpServletRequest.class, adapters = { CommerceDownload.class,
ComponentExporter.class }, resourceType = "ibm-commerce/components/download", defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME, extensions = ExporterConstants.SLING_MODEL_EXTENSION)
public class CommerceDownloadImpl implements CommerceDownload {
@Self
private SlingHttpServletRequest request;
@Self
@Via(type = ResourceSuperType.class)
private Download download;
@SlingObject
private ResourceResolver resourceResolver;
@ValueMapValue
private Boolean checkbox;
@ValueMapValue
private String fileReference;
public Boolean getCheckbox() {
return checkbox;
}
@Override
public String getSize() {
Resource resource = resourceResolver.getResource(fileReference);
String assetSize = "";
if (resource != null) {
Asset asset = resource.adaptTo(Asset.class);
assetSize = asset.getMetadataValue(DamConstants.DAM_SIZE);
}
return UIHelper.getSizeLabel(Long.parseLong(assetSize));
}
public void setCheckbox(Boolean checkbox) {
this.checkbox = checkbox;
}
}
