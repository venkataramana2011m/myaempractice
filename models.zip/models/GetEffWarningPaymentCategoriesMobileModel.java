package com.ibm.commerce.core.models;

import java.util.Optional;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.dam.cfm.ContentElement;
import com.adobe.cq.dam.cfm.ContentFragment;

@Model(adaptables = { Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class GetEffWarningPaymentCategoriesMobileModel {
	
	private static final Logger logger = LoggerFactory.getLogger(GetEffWarningPaymentCategoriesMobileModel.class);
	@Inject
    @Self
    private Resource resource;
    
	private Optional<ContentFragment> contentFragment;
	
	@PostConstruct
    public void init() {
        contentFragment = Optional.ofNullable(resource.adaptTo(ContentFragment.class));
    }
	
	public String getCategoryName() {
    	return contentFragment.map(cf -> cf.getElement("categoryName")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
	}
	
	public String getCategoryImageUrl() {
		return contentFragment.map(cf -> cf.getElement("categoryImageUrl")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
	}

	public String getCategoryQtn() {
		return contentFragment.map(cf -> cf.getElement("categoryQtn")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
		
	}

	public String getCategoryScamTitle() {
		return contentFragment.map(cf -> cf.getElement("categoryScamTitle")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
	}

	public String getCategoryScamSubTitle() {
		return contentFragment.map(cf -> cf.getElement("categoryScamSubTitle")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
	}

	public String getCategoryScamTextLine() {
		return contentFragment.map(cf -> cf.getElement("categoryScamTextLine")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
	}

	public String getDidyouknowImageUrl() {
		return contentFragment.map(cf -> cf.getElement("didyouknowImageUrl")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
	}

	public String getCategoryNoScamTitle() {
		return contentFragment.map(cf -> cf.getElement("categoryNoScamTitle")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
	}

	public String getCategoryNoScamTextLine() {
		return contentFragment.map(cf -> cf.getElement("categoryNoScamTextLine")).map(ContentElement::getContent).orElse(StringUtils.EMPTY);
	}

	/*public long getCategoryNumber() {
		
	    String categoryNumber = contentFragment.map(cf -> cf.getElement("categoryNumber")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
		long categoryNumberlongVal = Long.parseLong(categoryNumber);
		logger.info("long categoryNumber value is ****" + categoryNumberlongVal);
		return categoryNumberlongVal;
	}*/

	/*public Long getCategoryId() {
	    String categoryId = contentFragment.map(cf -> cf.getElement("categoryId")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
		long categoryIdlongVal = Long.parseLong(categoryId);
		logger.info("long categoryId value is ****" + categoryIdlongVal);
		return categoryIdlongVal;
	}*/
}
