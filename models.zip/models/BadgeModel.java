package com.ibm.commerce.core.models;

public interface BadgeModel {
	public String getBadgeAltText();
    public String getBadgeDecorative();
    public String getBadgeText() ;
    public String getBadgeType();

}
