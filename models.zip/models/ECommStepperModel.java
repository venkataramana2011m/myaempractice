package com.ibm.commerce.core.models;
public interface ECommStepperModel {
    public int getMinValue();
    public int getMaxValue();
    public String getMaxValueCheck();
    public String getMaxErrorMessage();
    public String getMinValueCheck();
    public String getMinErrorMessage();
    public int getDefValue();
}
