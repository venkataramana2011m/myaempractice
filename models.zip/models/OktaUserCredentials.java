package com.ibm.commerce.core.models;

public class OktaUserCredentials {

	private OktaUserPassword password;

	public OktaUserPassword getPassword() {
		return password;
	}

	public void setPassword(OktaUserPassword password) {
		this.password = password;
	}
}