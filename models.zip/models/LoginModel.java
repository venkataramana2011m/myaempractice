package com.ibm.commerce.core.models;

public interface LoginModel {
	
    String getTitle();

    String getText();

    String getButtonText();

    String getUserNameField();

    String getPasswordField();

    String getForgotPasswordField();

    public String getForgotPasswordLink();

    public String getRedirectPage();
}
