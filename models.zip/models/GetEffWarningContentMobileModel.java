package com.ibm.commerce.core.models;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.dam.cfm.ContentElement;
import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.cq.dam.cfm.FragmentData;

@Model(adaptables = { Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class GetEffWarningContentMobileModel {
	
	private static final Logger logger = LoggerFactory.getLogger(GetEffWarningContentMobileModel.class);

	@Inject
	@Self
	private Resource resource;

	@Self
	private GetEffWarningPaymentCategoriesMobileModel getEffWarningPaymentCategoriesMobileModelObj;

	private Optional<ContentFragment> contentFragment;
	
	@PostConstruct
	public void init() {
		contentFragment = Optional.ofNullable(resource.adaptTo(ContentFragment.class));
	}

	public String getNewrecipientReasonText() {
		return contentFragment.map(cf -> cf.getElement("newrecipientReasonText")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getScamPopupTitle() {
		return contentFragment.map(cf -> cf.getElement("scamPopupTitle")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getScamPopupText() {
		return contentFragment.map(cf -> cf.getElement("scamPopupText")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getDeadTileWarningTitle() {
		return contentFragment.map(cf -> cf.getElement("deadTileWarningTitle")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getDeadTileWarningSubTitle() {
		return contentFragment.map(cf -> cf.getElement("deadTileWarningSubTitle")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getDeadTileWarningText() {
		return contentFragment.map(cf -> cf.getElement("deadTileWarningText")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getNewrecipientReasonTitle() {
		return contentFragment.map(cf -> cf.getElement("newrecipientReasonTitle")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getDeadTiles() {
		return contentFragment.map(cf -> cf.getElement("deadTiles")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}
	
	public String getTalktousTitle() {
		return contentFragment.map(cf -> cf.getElement("talktousTitle")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousText() {
		return contentFragment.map(cf -> cf.getElement("talktousText")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousFpcImageUrl() {
		return contentFragment.map(cf -> cf.getElement("talktousFpcImageUrl")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousFpcTitle() {
				return contentFragment.map(cf -> cf.getElement("talktousFpcTitle")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousFpcLink() {
		return contentFragment.map(cf -> cf.getElement("talktousFpcLink")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousFpcText() {
		return contentFragment.map(cf -> cf.getElement("talktousFpcText")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousFunctionality() {
		return contentFragment.map(cf -> cf.getElement("talktousFunctionality")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousChatImageUrl() {
		
		return contentFragment.map(cf -> cf.getElement("talktousChatImageUrl")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousChatNowTitle() {
		return contentFragment.map(cf -> cf.getElement("talktousChatNowTitle")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	public String getTalktousChatNowLink() {
		return contentFragment.map(cf -> cf.getElement("talktousChatNowLink")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	/*public int getTalktousPhoneNumber() {
		String talktousPhoneNumber = contentFragment.map(cf -> cf.getElement("talktousPhoneNumber")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
		int talktousPhoneNumberlongVal = Integer.parseInt(talktousPhoneNumber); 
		logger.info("int talktousPhoneNumber value is ****" + talktousPhoneNumberlongVal);
		return talktousPhoneNumberlongVal;
	}*/

	public String getTalktousChatNowText() {
		return contentFragment.map(cf -> cf.getElement("talktousChatNowText")).map(ContentElement::getContent)
				.orElse(StringUtils.EMPTY);
	}

	
	public List<GetEffWarningPaymentCategoriesMobileModel> getPaymentCategoriesMobile() {

		return Arrays
				.asList((String[]) contentFragment.map(cf -> cf.getElement("paymentCategoriesMobile"))
						.map(ContentElement::getValue).map(FragmentData::getValue).orElse(new String[0]))
				.stream().map(paymentCategoriesPath -> resource.getResourceResolver().resolve(paymentCategoriesPath))
				.filter(Objects::nonNull).map(paymentCategoriesPathResource -> paymentCategoriesPathResource
						.adaptTo(GetEffWarningPaymentCategoriesMobileModel.class))
				.collect(Collectors.toList());
	}
}