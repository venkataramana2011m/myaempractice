package com.ibm.commerce.core.models;
import lombok.Getter;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

import javax.inject.Inject;

import java.util.List;

@Model(
 adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)

public class EcommColumncontainerModel {

    @ChildResource
    @Getter
    private List<GridDetailsModel> extraExtraLargeGridDetails;

    @ChildResource
    @Getter
    private List<GridDetailsModel> extraLargeGridDetails;

    @ChildResource
    @Getter
    private List<GridDetailsModel> largeGridDetails;

    @ChildResource
    @Getter
    private List<GridDetailsModel> mediumGridDetails;

    @ChildResource
    @Getter
    private List<GridDetailsModel> smallGridDetails;

    @Inject
    @Getter
    public String backgroundImage;

    @Inject
    @Getter
    public String addSpace;

    @Inject
    @Getter
    public String borderRequired;

    @Inject
    @Getter
    public String borderClass;

    @Inject
    @Getter
    public String backgroundColor;
}

