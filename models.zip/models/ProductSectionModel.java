package com.ibm.commerce.core.models;

import java.util.List;

public interface ProductSectionModel {
	public String getBadgeChecked();

    public  int getNumber();
    public List<Integer> getButtonList();
    public String getButtonCount();

    public String getDescription();

    public String getId();

/*
    public String getSize();
*/

    /*public String getText();*/

    public String getImageSize();

    public String getProductsectiontype();

     String getTitle();

}
