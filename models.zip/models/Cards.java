package com.ibm.commerce.core.models;
import java.util.List;
import java.util.Map;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import com.adobe.cq.wcm.core.components.models.Teaser;

public interface Cards extends Teaser{
	
	public String getResourceType();

	public List<Map<String,String>> getActionItems(); 
	  	 
	public String getAction();

	public Resource getCurrentResource();

	public ResourceResolver getResourceResolver();
    
	@Override
	public String getDescription();
	
	@Override
	public String getTitle();

	public String getModalIcon();

	public String getHoverText();

	public String getCtaTwo();

	public String getCtaOne();

	public boolean isClickable();

	public String getCardLink();

	public String getExternal();
	
	public String getCategories();
    public String getSubTitle();
    public String getCardDate();
	
    @Override
	public Resource getImageResource();
	
}
