package com.ibm.commerce.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.ibm.commerce.core.models.ECommerceSignupConfigModel;
import com.ibm.commerce.core.services.ECommerceSignupConfigService;

@Model(adaptables = SlingHttpServletRequest.class,
adapters = ECommerceSignupConfigModel.class,
defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ECommerceSignupConfigModelImpl implements ECommerceSignupConfigModel {

	 @OSGiService
	 ECommerceSignupConfigService oSGiConfig;
	@Override
	public String getEndpoint() {
		return oSGiConfig.getEndpoint();
	}

	@Override
	public String getInstanceid() {
		return oSGiConfig.getInstanceid();
	}

	@Override
	public String getInstancekey() {
		return oSGiConfig.getInstancekey();
	}

	@Override
	public String getApikey() {
		return oSGiConfig.getApikey();
	}

	@Override
	public String getApihost() {
		return oSGiConfig.getApihost();
	}

}
