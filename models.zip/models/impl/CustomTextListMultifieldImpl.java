package com.ibm.commerce.core.models.impl;

import com.ibm.commerce.core.models.CustomTextListMultifieldModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.*;

@Model(adaptables = { SlingHttpServletRequest.class,
        Resource.class },adapters = CustomTextListMultifieldModel.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CustomTextListMultifieldImpl implements CustomTextListMultifieldModel{
	public static final String RESOURCE_TYPE = "ibm-commerce/components/customtextlist";
    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String destinationURL;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String externalLink;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String listTitle;

    @Override
    public String getDestinationURL() {
        return destinationURL;
    }
    
    @Override
    public String getExternalLink() {
        return externalLink;
    }
    
    @Override
    public String getListTitle() {
        return listTitle;
    }
}
