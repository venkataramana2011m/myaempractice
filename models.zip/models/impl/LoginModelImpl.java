package com.ibm.commerce.core.models.impl;

import com.ibm.commerce.core.models.LoginModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
@Model(adaptables = {Resource.class, SlingHttpServletRequest.class},
        adapters = LoginModel.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL,
        resourceType = LoginModelImpl.RESOURCE_TYPE)
public class LoginModelImpl implements LoginModel {
    static final String RESOURCE_TYPE = "ibm-commerce/components/login";
    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String title;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String text;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String buttonText;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String userNameField;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String passwordField;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String forgotPasswordField;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String forgotPasswordLink;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    String redirectPage;


    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getText() {
        return text;
    }
    @Override
    public String getButtonText() {
        return buttonText;
    }
    @Override
    public String getUserNameField() {
        return userNameField;
    }
    @Override
    public String getPasswordField() {
        return passwordField;
    }

    public String getForgotPasswordLink() {
        return forgotPasswordLink;
    }
    
    @Override
    public String getForgotPasswordField() {
        return forgotPasswordField;
    }
    @Override
    public String getRedirectPage() {
        return redirectPage;
    }
}
