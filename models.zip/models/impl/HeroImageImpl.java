package com.ibm.commerce.core.models.impl;

import com.adobe.cq.export.json.ExporterConstants;
import com.ibm.commerce.core.models.HeroImage;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;

@Model(adaptables = {Resource.class, SlingHttpServletRequest.class},
        adapters = HeroImage.class,resourceType = HeroImageImpl.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION)
public class HeroImageImpl implements HeroImage {
    private static final String PN_FULL_WIDTH = "useFullWidth";
    public static final String RESOURCE_TYPE = "ibm-commerce/components/heroimage";

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue
    private  String heading;

    @ValueMapValue
    private  String title;

    @ValueMapValue
    private  String buttonLabel;

    @ValueMapValue
    private  String buttonLinkTo;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String useFullWidth;

    private String classList;

    private String imageSrc = StringUtils.EMPTY;

    @PostConstruct
    private void initModel() {
        classList = getClassList();
    }
    @Override
    public String getClassList() {
        if (classList != null) {
            return classList;
        }
        classList = "ibm-HeroImage";
        if ("true".equals(useFullWidth)) {
            classList += " width-full";
        }
        return classList;
    }
    @Override
    public String getHeading() {
        return heading;
    }
    @Override
    public String getTitle() {
        return title;
    }
    @Override
    public String getButtonLabel() {
        return buttonLabel;
    }
    @Override
    public String getButtonLinkTo() {
        return buttonLinkTo;
    }

    public String getImageSrc() {
        com.adobe.cq.wcm.core.components.models.Image image = request.adaptTo(com.adobe.cq.wcm.core.components.models.Image.class);
        if(image != null) {
            imageSrc = image.getSrc();
        }
        return imageSrc;
    }
}
