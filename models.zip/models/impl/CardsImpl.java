
package com.ibm.commerce.core.models.impl;

import static org.apache.sling.api.resource.ResourceResolver.PROPERTY_RESOURCE_TYPE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.day.cq.commons.jcr.JcrConstants;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.api.SlingHttpServletRequest;

import org.apache.sling.models.annotations.*;


import com.adobe.cq.wcm.core.components.models.Teaser;



import javax.inject.Named;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.via.ResourceSuperType;


import com.adobe.cq.export.json.ComponentExporter;
import com.adobe.cq.export.json.ExporterConstants;
import com.ibm.commerce.core.models.Cards;

@Model(adaptables = SlingHttpServletRequest.class,adapters = {ComponentExporter.class,Cards.class},
defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL,
resourceType=CardsImpl.RESOURCE_TYPE
)
@Exporter(name=ExporterConstants.SLING_MODEL_EXPORTER_NAME,extensions=ExporterConstants.SLING_MODEL_EXTENSION)
public class CardsImpl implements Cards{
	
	public static final String RESOURCE_TYPE="ibm-commerce/components/cards";
	public static final String HTML = ".html";
	public static final String LINKVALUES = "linkvalue";
	@Self
	@Via(type=ResourceSuperType.class)
	private Teaser teaser;
	
    @ValueMapValue(name=PROPERTY_RESOURCE_TYPE, injectionStrategy=InjectionStrategy.OPTIONAL)
    @Default(values="No resourceType")
    protected String resourceType;

    @SlingObject
    private Resource currentResource;
    @SlingObject
    private ResourceResolver resourceResolver;
    
    @ValueMapValue
    @Via("resource")
    @Named(JcrConstants.JCR_TITLE)
	private String title;
    
    @ValueMapValue
    @Via("resource")
    @Named(JcrConstants.JCR_DESCRIPTION)
	private String description;
    
    @ValueMapValue 
	private String modalIcon;
    
    @ValueMapValue 
	private String hoverText;
        
    @ValueMapValue 
	private String ctaTwo;
    
    @ValueMapValue
	private String ctaOne;
    
    @ValueMapValue 
	private boolean clickable;
    
    @ValueMapValue 
	private String cardLink;
    
    @ValueMapValue 
	private String external;
    
    @ValueMapValue
    private String action;
    
    @ValueMapValue
    private String categories;
    
    @ValueMapValue
    private String subTitle;
    
    @ValueMapValue
    private String cardDate;
    
    
    @Override
	public String getResourceType() {
		return resourceType;
	}
	
	@Override
	  public List<Map<String,String>> getActionItems() {
		
		  List<Map<String,String>> actionItemms= new ArrayList<>();
		  Resource res = currentResource.getChild("actionitems");

		  if(res!=null) {
			  for(Resource actionitem : res.getChildren()) {
				  Map<String,String> actionMap = new HashMap<>();
					if(actionitem!=null && actionitem.getValueMap()!=null &&
							actionitem.getValueMap().get(LINKVALUES,String.class)!=null){
						actionMap.put(LINKVALUES, actionitem.getValueMap().get(LINKVALUES,String.class).endsWith(HTML)?actionitem.getValueMap().get(LINKVALUES,String.class):actionitem.getValueMap().get(LINKVALUES,String.class).concat(HTML));
						actionMap.put("textvalue", actionitem.getValueMap().get("textvalue",String.class));
						actionItemms.add(actionMap);
					}
			  }
		  }
		return actionItemms;
	}

	  @Override
	public String getAction() {
		return action;
	}

	@Override
	public Resource getCurrentResource() {
		return currentResource;
	}

	@Override
	public ResourceResolver getResourceResolver() {
		return resourceResolver;
	}
	
	@Override
	public String getDescription() {
		return description;
	}
	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getModalIcon() {
		return modalIcon;
	}

	@Override
	public String getHoverText() {
		return hoverText;
	}

	@Override
	public String getCtaTwo() {
		return ctaTwo;
	}

	@Override
	public String getCtaOne() {
		return ctaOne;
	}
	@Override
	public boolean isClickable() {
		return clickable;
	}

	@Override
	public String getCardLink() {
		return cardLink.endsWith(HTML)?cardLink:(cardLink+HTML);
	}

	@Override
	public String getExternal() {
		return external;
	}
	
	@Override
	public Resource getImageResource() {

		return teaser.getImageResource();
	}
	@Override
    public String getCategories(){
     return categories;
    }
    @Override
    public String getSubTitle(){
     return subTitle;
    }
    @Override
    public String getCardDate(){
     return cardDate;
    } 

}
