package com.ibm.commerce.core.models.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.PostConstruct;
import com.ibm.commerce.core.models.ProductSectionModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import com.adobe.cq.export.json.ExporterConstants;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = { SlingHttpServletRequest.class,Resource.class },
        adapters = ProductSectionModel.class ,resourceType = ProductSectionImpl.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name = ExporterConstants.SLING_MODEL_EXPORTER_NAME,
        extensions = ExporterConstants.SLING_MODEL_EXTENSION)
public class ProductSectionImpl implements ProductSectionModel{
    public static final String RESOURCE_TYPE = "ibm-commerce/components/productsection";

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String buttonCount;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String description;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String imageSize;

    @ValueMapValue
    private String title;

    @ValueMapValue
    private String id;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String productsectiontype;

    private List<Integer> buttonList = new ArrayList<>();

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String badgeChecked;

    private int number;
    @PostConstruct
	protected void init() {
        number = Integer.parseInt(buttonCount);
        for(int i=0;i<number;i++){
            buttonList.add(i);
        }
    }
    @Override
    public String getBadgeChecked() {
        return badgeChecked;
    }
    
    @Override
    public  int getNumber() {
        return number;
    }
    
    @Override
    public List<Integer> getButtonList() {
        return Collections.unmodifiableList(buttonList);
    }
    
    @Override
    public String getButtonCount() {
        return buttonCount;
    }
    
    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getImageSize() {
        return imageSize;
    }

    @Override
    public String getProductsectiontype() {
        return productsectiontype;
    }

    @Override
    public String getTitle() {
        return title;
    }
}
