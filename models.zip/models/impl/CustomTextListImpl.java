package com.ibm.commerce.core.models.impl;

import java.util.List;
import com.ibm.commerce.core.models.CustomTextListModel;
import com.ibm.commerce.core.models.CustomTextListMultifieldModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.*;


@Model(adaptables = { SlingHttpServletRequest.class,
        Resource.class },adapters = CustomTextListModel.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CustomTextListImpl implements CustomTextListModel{
	public static final String RESOURCE_TYPE = "ibm-commerce/components/customtextlist";
	
    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String headerTitle;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String listType;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String textBelowList;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String textAboveList;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String textIsRich;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String title;

    @ChildResource
    List<CustomTextListMultifieldModel> textList;


    public String getHeaderTitle() {
        return headerTitle;
    }

    public String getListType() {
        return listType;
    }

    public String getTextBelowList() {
        return textBelowList;
    }

    public String getTextIsRich() {
        return textIsRich;
    }

    public String getTitle() {
        return title;
    }

    public List<CustomTextListMultifieldModel> getTextList() {
        return textList;
    }

    public String getTextAboveList() {
        return textAboveList;
    }
}
