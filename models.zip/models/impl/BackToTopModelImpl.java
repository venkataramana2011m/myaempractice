package com.ibm.commerce.core.models.impl;

import com.ibm.commerce.core.models.BackToTopModel;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
@Model(adaptables = {
        Resource.class,
        SlingHttpServletRequest.class
    },
    adapters = BackToTopModel.class,
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL,
    resourceType = BackToTopModelImpl.RESOURCE_TYPE)
public class BackToTopModelImpl implements BackToTopModel {
    static final String RESOURCE_TYPE = "ibm-commerce/components/backtotop";

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String buttontype;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String text;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String textwithicon;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String icon;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String buttonposition;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String screensize;

    @ValueMapValue
    private boolean sticky;

    @Override
    public String getButtonType() {
        return buttontype;
    }

    @Override
    public String getButtonText() {
        return text;
    }

    @Override
    public String getTextWithIcon() {
        return textwithicon;
    }

    @Override
    public String getIcon() {
        return icon;
    }

    @Override
    public String getButtonPosition() {
        return buttonposition;
    }

    @Override
    public String getScreenSize() {
        return screensize;
    }

    @Override
    public boolean getButtonSticky() {
        return sticky;
    }

}