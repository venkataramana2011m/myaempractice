package com.ibm.commerce.core.models.impl;

import com.ibm.commerce.core.beans.DynamicCardListBean;
import com.ibm.commerce.core.models.DynamicCardListModel;
import com.ibm.commerce.core.services.DynamicCardListService;


import java.util.List;

import javax.annotation.PostConstruct;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;
import com.day.cq.tagging.Tag;
import java.util.HashSet;

@Model(adaptables = {
        Resource.class,
        SlingHttpServletRequest.class
    },
    adapters = DynamicCardListModel.class,
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL,
    resourceType = DynamicCardListModelImpl.RESOURCE_TYPE)
public class DynamicCardListModelImpl implements DynamicCardListModel {
    static final String RESOURCE_TYPE = "ibm-commerce/components/dynamic_card_list";

    private static final Logger log = LoggerFactory.getLogger(DynamicCardListModelImpl.class);
    
    @OSGiService
    DynamicCardListService dynamicCardListService;
    
    Tag[] tags;
    Tag tag;
    
    HashSet <String> tagNamesList = new HashSet<>();
    
    @ScriptVariable
    Page currentPage;
    
    String tagName;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String componenttype;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String defaultimage;

    @ValueMapValue
    private int cardscount;
      
    @Override
    public String getCardListType() {
        return componenttype;
    }

    @Override
    public String getCardListDefaultImage() {
        return defaultimage;
    }

    @Override
    public int getCardListCount() {
        return cardscount;
    }

    @Override
    public String getPageTitle() {
        return currentPage.getTitle();
        
    }
    @Override
    public String getPagePath() {
        return currentPage.getPath();
    }   
               
    @PostConstruct
    protected void init() throws PathNotFoundException, RepositoryException {
        try {
        	 tags = currentPage.getTags();                   
             for (Tag tag: tags) {
                 tagName = tag.getName();
                 tagNamesList.add(tagName);
             }
             dynamicCardListService.getCardList(getPagePath(), getPageTitle(), tagNamesList,defaultimage);

        } catch (LoginException e) {
            e.printStackTrace();
        }
    }

    public List <DynamicCardListBean> getCardlist() throws LoginException, RepositoryException {
        return dynamicCardListService.getCardList(getPagePath(), getPageTitle(), tagNamesList, defaultimage);

    }
}