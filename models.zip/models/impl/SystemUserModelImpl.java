package com.ibm.commerce.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ibm.commerce.core.models.SystemUserModel;
import com.ibm.commerce.core.services.AresourceResolverService;
import com.ibm.commerce.core.services.EcommResourcePropertiesServices;
import org.apache.commons.lang3.StringUtils;

/**
 * @author 001YYG744
 *
 */
@Model(adaptables = { Resource.class,
		SlingHttpServletRequest.class }, adapters = SystemUserModel.class, resourceType = SystemUserModelImpl.RESOURCE_TYPE, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SystemUserModelImpl implements SystemUserModel {
	public static final String RESOURCE_TYPE = "/ibm-commerce/components/ecomm-systemuser";
	// hard coded path
	String resourcePath = "/content/ibm-commerce/us/en/ecomuser/jcr:content/root/container/container/ecomm_systemuser";

	private final static Logger logger = LoggerFactory.getLogger(SystemUserModelImpl.class);

	@OSGiService
	AresourceResolverService aresourceResolverServiceObj;

	@SlingObject
	SlingHttpServletRequest requestObj;

	@OSGiService
	EcommResourcePropertiesServices ecommResourcePropertiesServicesObj;
    
	@Override
	public String getStepperCombinedMsg() {
		String stepperCombinedMsg = null;
		String stepperCombinedMsgVal = null;
		ResourceResolver resolverObj = null;
		try {
			logger.info("Method name getStepperCombinedMsg Current page is *****" + requestObj.getPathInfo());
			String currentPagePath = requestObj.getPathInfo();
			Integer currentPageWithouthtmlIndex = currentPagePath.indexOf(".html");
			String pathWithouthtml = currentPagePath.substring(0, currentPageWithouthtmlIndex);
			logger.info("Customized path is  *****" + pathWithouthtml + " html Index is *** "
					+ currentPageWithouthtmlIndex);
			String stepperResPath = pathWithouthtml + "/jcr:content/root/container/container/ecomm_stepper";
			// dynamic code path
			resolverObj = aresourceResolverServiceObj.getResourceResolver();
			if (resolverObj != null) {
				stepperCombinedMsgVal = ecommResourcePropertiesServicesObj.getEcommsStepperCombinedMsg(resolverObj,
						stepperResPath);
				if (!StringUtils.isEmpty(stepperCombinedMsgVal)) {
					stepperCombinedMsg = stepperCombinedMsgVal;
				}
			}
		} catch (StringIndexOutOfBoundsException ex) {
			logger.error("exception value from method name getEcommsStepperCombinedMsg" + ex.getStackTrace());

		} finally {
			if (resolverObj != null && resolverObj.isLive()) {
				resolverObj.close();
				logger.info("resolver is closed from method name getStepperCombinedMsg");
			}
		}

		return stepperCombinedMsg;

	}

	/**
	 * @return the ecommSystemUserName
	 */
	@Override
	public String getEcommSystemUserName() {
		ResourceResolver resolver = null;
		String ecommSystemUserName = null;
		String ecommSystemUserNameVal = null;
		try {
			resolver = aresourceResolverServiceObj.getResourceResolver();
			if (null != resolver) {
				logger.info("resolver is***" + resolver.getUserID());
				ecommSystemUserNameVal = aresourceResolverServiceObj.getResourceResolver().getUserID();
				if (!StringUtils.isEmpty(ecommSystemUserNameVal)) {
					ecommSystemUserName = ecommSystemUserNameVal;
				}
			}
		} catch (StringIndexOutOfBoundsException ex) {
			logger.error("Exception from getEcommSystemUserName***" + ex.getMessage());
		} finally {
			if (resolver != null && resolver.isLive()) {
				resolver.close();
				logger.info("resolver is closed from getEcommSystemUserName");
			}
		}
		return ecommSystemUserName;

	}

	/**
	 * @return the serviceUserTitle
	 */
	@Override
	public String getServiceUserTitle() {
		String serviceUserTitle = null;
		String serviceUserTitleVal = null;
		ResourceResolver resolver = null;
		try {
			resolver = aresourceResolverServiceObj.getResourceResolver();
			if (null != resolver) {
			logger.info("read request object*****" + requestObj.getPathInfo());
			if (!StringUtils.isEmpty(resourcePath)) {
				logger.info("inside method name****" + "*****getServiceUserTitle");
				serviceUserTitleVal = ecommResourcePropertiesServicesObj.getResourceTitle(resourcePath,resolver);
				  if(!StringUtils.isEmpty(serviceUserTitleVal))
						{
					       serviceUserTitle=serviceUserTitleVal;
						}
				}
			}}
		catch (StringIndexOutOfBoundsException ex) {
			logger.error("Exception from*** method is getServiceUserTitle" + ex.getMessage());
		}finally {
			if (resolver != null && resolver.isLive()) {
				resolver.close();
				logger.info("resolver is closed from getServiceUserTitle");
			}
		}

		return serviceUserTitle;
	}

}
