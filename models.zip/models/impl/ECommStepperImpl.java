package com.ibm.commerce.core.models.impl;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.ibm.commerce.core.models.ECommStepperModel;
@Model(adaptables = {Resource.class,SlingHttpServletRequest.class},
        adapters = ECommStepperModel.class, resourceType = ECommStepperImpl.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ECommStepperImpl implements ECommStepperModel {
    public static final String RESOURCE_TYPE = "ibm-commerce/components/ecomm-stepper";
    @ValueMapValue
    private int minValue;
    @ValueMapValue
    private int maxValue;
    @ValueMapValue
    private String maxValueCheck;
    @ValueMapValue
    private String maxErrorMessage;
    @ValueMapValue
    private String minValueCheck;
    @ValueMapValue
    private String minErrorMessage;
    @ValueMapValue
    private int defValue;

    @Override
    public int getMinValue() {
        return minValue;
    }
    @Override
    public int getMaxValue() {
        return maxValue;
    }
    @Override
    public String getMaxValueCheck() {
        return maxValueCheck;
    }
    @Override
    public String getMaxErrorMessage() {
        return maxErrorMessage;
    }
    @Override
    public String getMinValueCheck() {
        return minValueCheck;
    }
    @Override
    public String getMinErrorMessage() {
        return minErrorMessage;
    }
    @Override
    public int getDefValue() {
        return defValue;
    }
}