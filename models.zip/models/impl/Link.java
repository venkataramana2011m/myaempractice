package com.ibm.commerce.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.injectorspecific.*;
import org.apache.sling.models.annotations.via.ResourceSuperType;
import org.osgi.annotation.versioning.ConsumerType;

import com.adobe.cq.wcm.core.components.models.Button;
@Model(adaptables = SlingHttpServletRequest.class,
defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
@ConsumerType
public class Link implements Button{

	@Via(type=ResourceSuperType.class)
	private Button button;

	@ValueMapValue
	private String action;
	
	@ValueMapValue
	private String popupUrl;
	
	@ValueMapValue
	private boolean external;
	
	@ValueMapValue
	private boolean redirectConfirm;
	
	@ValueMapValue
	private String modalIcon;
	
	@ValueMapValue
	private String modalTitle;
	
	public boolean isExternal() {
		return external;
	}
	
	public boolean isRedirectConfirm() {
		return redirectConfirm;
	}
	
	public String getAction() {
		return action;
	}
	
	public String getPopupUrl() {
		return popupUrl;
	}
	public String getModalIcon() {
		return modalIcon;
	}
	public String getModalTitle() {
		return modalTitle;
	}
	public Button getButton() {
		return button;
	}
    
}
