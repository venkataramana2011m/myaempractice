package com.ibm.commerce.core.models.impl;

import com.ibm.commerce.core.models.VideoModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.*;


@Model(adaptables = { SlingHttpServletRequest.class,
        Resource.class },adapters = VideoModel.class,
        resourceType = VideoImpl.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class VideoImpl implements VideoModel {
	public static final String RESOURCE_TYPE = "ibm-commerce/components/videocomponent";
    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String accountID;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String playerID;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String videoID;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String videoIframeLang;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String videoIframeTitle;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String videoType;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String videoUrl;


    @Override
    public String getAccountID() {
        return accountID;
    }

    @Override
    public String getPlayerID() {
        return playerID;
    }

    @Override
    public String getVideoID() {
        return videoID;
    }

    @Override
    public String getVideoIframeLang() {
        return videoIframeLang;
    }

    @Override
    public String getVideoIframeTitle() {
        return videoIframeTitle;
    }

    @Override
    public String getVideoType() {
        return videoType;
    }

    @Override
    public String getVideoUrl() {
        return videoUrl;
    }
}
