package com.ibm.commerce.core.models.impl;

import com.ibm.commerce.core.models.BadgeModel;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.*;


@Model(adaptables = { SlingHttpServletRequest.class,
        Resource.class },adapters = BadgeModel.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class BadgeImpl implements BadgeModel{
	public static final String RESOURCE_TYPE = "ibm-commerce/components/badge";
    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String badgeAltText;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String badgeDecorative;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String badgeText;

    @ValueMapValue
    @Default(values = StringUtils.EMPTY)
    private String badgeType;


    
    @Override
    public String getBadgeAltText() {
        return badgeAltText;
    }

    public String getBadgeDecorative() {
        return badgeDecorative;
    }

    public String getBadgeText() {
        return badgeText;
    }

    public String getBadgeType() {
        return badgeType;
    }
}
