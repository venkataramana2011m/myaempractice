package com.ibm.commerce.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.ibm.commerce.core.models.HeroBanner;

@Model(adaptables = {Resource.class,SlingHttpServletRequest.class}, 
	adapters = HeroBanner.class, resourceType = HeroBannerModel.RESOURCE_TYPE,
	defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HeroBannerModel implements HeroBanner {
    public static final String RESOURCE_TYPE = "ibm-commerce/components/herobanner";


	@ValueMapValue
	private String fileReference;

	@ValueMapValue
	private String title;

	@ValueMapValue
	private String subtitle;

	@ValueMapValue
	private String description;

	@ValueMapValue
	private String alttext;

	@ValueMapValue
	private String id;

	@ValueMapValue
	private String pretitle;
	
	@ValueMapValue
	private String height;
	
	@ValueMapValue
	private String buttons;
	
	@ValueMapValue
	private String startcolor;
	
	@ValueMapValue
	private String startcolorposition;
	
	@ValueMapValue
	private String endcolor;
	
	@ValueMapValue
	private String endcolorposition;
	
	@ValueMapValue
	private String expfrag;

	@Override
	public String getPretitle() {
		return pretitle;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public String getAlttext() {
		return alttext;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getSubtitle() {
		return subtitle;
	}

	@Override
	public String getFileReference() {
		return fileReference;
	}

	@Override
	public String getHeight() {
		return height;
	}

	@Override
	public String getButtons() {
		return buttons;
	}

	@Override
	public String getStartcolor() {
		return startcolor;
	}

	@Override
	public String getStartcolorposition() {
		return startcolorposition;
	}

	@Override
	public String getEndcolor() {
		return endcolor;
	}

	@Override
	public String getEndcolorposition() {
		return endcolorposition;
	}

	@Override
	public String getExpfrag() {
		return expfrag;
	}
}
