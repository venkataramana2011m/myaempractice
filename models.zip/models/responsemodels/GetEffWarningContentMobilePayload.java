package com.ibm.commerce.core.models.responsemodels;

import java.util.List;

import com.ibm.commerce.core.models.GetEffWarningPaymentCategoriesMobileModel;

public class GetEffWarningContentMobilePayload {
	
	private GetEffWarningContentMobileMainContent mainContent;
	private GetEffWarningContentMobileTalktous talktous;
	private String[] deadTiles;
	//private String[] paymentCategoriesMobile;
	private List<PaymentCategoriesMobilePayload> paymentCategoriesMobile;
	

	public List<PaymentCategoriesMobilePayload> getPaymentCategoriesMobile() {
		return paymentCategoriesMobile;
	}

	public void setPaymentCategoriesMobile(List<PaymentCategoriesMobilePayload> paymentCategoriesMobile) {
		this.paymentCategoriesMobile = paymentCategoriesMobile;
	}

	public String[] getDeadTiles() {
		return deadTiles;
	}

	public void setDeadTiles(String[] deadTiles) {
		this.deadTiles = deadTiles;
	}

	private PaymentCategoriesMobilePayload PaymentCategoriesMobilePayload;

	public PaymentCategoriesMobilePayload getPaymentCategoriesMobilePayload() {
		return PaymentCategoriesMobilePayload;
	}

	public void setPaymentCategoriesMobilePayload(PaymentCategoriesMobilePayload paymentCategoriesMobilePayload) {
		PaymentCategoriesMobilePayload = paymentCategoriesMobilePayload;
	}

	public GetEffWarningContentMobileTalktous getTalktous() {
		return talktous;
	}

	public void setTalktous(GetEffWarningContentMobileTalktous talktous) {
		this.talktous = talktous;
	}

	public GetEffWarningContentMobileMainContent getMainContent() {
		return mainContent;
	}

	public void setMainContent(GetEffWarningContentMobileMainContent mainContent) {
		this.mainContent = mainContent;
	}
	
	
}
