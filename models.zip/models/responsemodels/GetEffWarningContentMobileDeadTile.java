package com.ibm.commerce.core.models.responsemodels;

public class GetEffWarningContentMobileDeadTile {
	private  String[] deadTiles;

	public String[] getDeadTiles() {
		return deadTiles;
	}

	public void setDeadTiles(String[] deadTiles) {
		this.deadTiles = deadTiles;
	}
}