package com.ibm.commerce.core.models.responsemodels;

public class GetEffWarningContentMobileMainContent {
	
	String newrecipientReasonTitle;
	String newrecipientReasonText;
	String scamPopupTitle;
	String scamPopupText;
	String deadTileWarningTitle;
	String deadTileWarningSubTitle;
	String deadTileWarningText;
	
	public String getScamPopupTitle() {
		return scamPopupTitle;
	}
	public void setScamPopupTitle(String scamPopupTitle) {
		this.scamPopupTitle = scamPopupTitle;
	}
	public String getScamPopupText() {
		return scamPopupText;
	}
	public void setScamPopupText(String scamPopupText) {
		this.scamPopupText = scamPopupText;
	}
	public String getDeadTileWarningTitle() {
		return deadTileWarningTitle;
	}
	public void setDeadTileWarningTitle(String deadTileWarningTitle) {
		this.deadTileWarningTitle = deadTileWarningTitle;
	}
	public String getDeadTileWarningSubTitle() {
		return deadTileWarningSubTitle;
	}
	public void setDeadTileWarningSubTitle(String deadTileWarningSubTitle) {
		this.deadTileWarningSubTitle = deadTileWarningSubTitle;
	}
	public String getDeadTileWarningText() {
		return deadTileWarningText;
	}
	public void setDeadTileWarningText(String deadTileWarningText) {
		this.deadTileWarningText = deadTileWarningText;
	}
	public String getNewrecipientReasonTitle() {
		return newrecipientReasonTitle;
	}
	public void setNewrecipientReasonTitle(String newrecipientReasonTitle) {
		this.newrecipientReasonTitle = newrecipientReasonTitle;
	}
	public String getNewrecipientReasonText() {
		return newrecipientReasonText;
	}
	public void setNewrecipientReasonText(String newrecipientReasonText) {
		this.newrecipientReasonText = newrecipientReasonText;
	}
}