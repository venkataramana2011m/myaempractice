package com.ibm.commerce.core.models.responsemodels;

import java.util.List;
public class PaymentCategoriesMobilePayload {
 private Long categoryId;
 private String categoryName;
 private String categoryImageUrl;
 private String categoryQtn;
 private String categoryScamTitle;
 private String categoryScamSubTitle;
 private String categoryScamTextLine;
 private String didyouknowImageUrl;
 private String categoryNoScamTitle;
 private String categoryNoScamTextLine;
 private Long  categoryNumber;
 
public Long getCategoryId() {
	return categoryId;
}
public void setCategoryId(Long categoryId) {
	this.categoryId = categoryId;
}
public String getCategoryName() {
	return categoryName;
}
public void setCategoryName(String categoryName) {
	this.categoryName = categoryName;
}
public String getCategoryImageUrl() {
	return categoryImageUrl;
}
public void setCategoryImageUrl(String categoryImageUrl) {
	this.categoryImageUrl = categoryImageUrl;
}
public String getCategoryQtn() {
	return categoryQtn;
}
public void setCategoryQtn(String categoryQtn) {
	this.categoryQtn = categoryQtn;
}
public String getCategoryScamTitle() {
	return categoryScamTitle;
}
public void setCategoryScamTitle(String categoryScamTitle) {
	this.categoryScamTitle = categoryScamTitle;
}
public String getCategoryScamSubTitle() {
	return categoryScamSubTitle;
}
public void setCategoryScamSubTitle(String categoryScamSubTitle) {
	this.categoryScamSubTitle = categoryScamSubTitle;
}
public String getCategoryScamTextLine() {
	return categoryScamTextLine;
}
public void setCategoryScamTextLine(String categoryScamTextLine) {
	this.categoryScamTextLine = categoryScamTextLine;
}
public String getDidyouknowImageUrl() {
	return didyouknowImageUrl;
}
public void setDidyouknowImageUrl(String didyouknowImageUrl) {
	this.didyouknowImageUrl = didyouknowImageUrl;
}
public String getCategoryNoScamTitle() {
	return categoryNoScamTitle;
}
public void setCategoryNoScamTitle(String categoryNoScamTitle) {
	this.categoryNoScamTitle = categoryNoScamTitle;
}
public String getCategoryNoScamTextLine() {
	return categoryNoScamTextLine;
}
public void setCategoryNoScamTextLine(String categoryNoScamTextLine) {
	this.categoryNoScamTextLine = categoryNoScamTextLine;
}
public Long getCategoryNumber() {
	return categoryNumber;
}
public void setCategoryNumber(Long categoryNumber) {
	this.categoryNumber = categoryNumber;
}
}
