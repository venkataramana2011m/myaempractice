package com.ibm.commerce.core.models.responsemodels;

public class GetEffWarningContentMobileTalktous {
	
	String talktousTitle;
	String talktousText;
	String talktousFpcImageUrl;
	String talktousFpcTitle;
	String talktousFpcLink;
	String talktousFpcText;
	String talktousFunctionality;
	String talktousChatImageUrl;
	String talktousChatNowTitle;
	String talktousChatNowLink;
	String talktousChatNowText;
	long talktousPhoneNumber;
	
	public String getTalktousFpcImageUrl() {
		return talktousFpcImageUrl;
	}
	public void setTalktousFpcImageUrl(String talktousFpcImageUrl) {
		this.talktousFpcImageUrl = talktousFpcImageUrl;
	}
	public String getTalktousFpcTitle() {
		return talktousFpcTitle;
	}
	public void setTalktousFpcTitle(String talktousFpcTitle) {
		this.talktousFpcTitle = talktousFpcTitle;
	}
	public String getTalktousFpcLink() {
		return talktousFpcLink;
	}
	public void setTalktousFpcLink(String talktousFpcLink) {
		this.talktousFpcLink = talktousFpcLink;
	}
	public String getTalktousFpcText() {
		return talktousFpcText;
	}
	public void setTalktousFpcText(String talktousFpcText) {
		this.talktousFpcText = talktousFpcText;
	}
	public String getTalktousFunctionality() {
		return talktousFunctionality;
	}
	public void setTalktousFunctionality(String talktousFunctionality) {
		this.talktousFunctionality = talktousFunctionality;
	}
	public String getTalktousChatImageUrl() {
		return talktousChatImageUrl;
	}
	public void setTalktousChatImageUrl(String talktousChatImageUrl) {
		this.talktousChatImageUrl = talktousChatImageUrl;
	}
	public String getTalktousChatNowTitle() {
		return talktousChatNowTitle;
	}
	public void setTalktousChatNowTitle(String talktousChatNowTitle) {
		this.talktousChatNowTitle = talktousChatNowTitle;
	}
	public String getTalktousChatNowLink() {
		return talktousChatNowLink;
	}
	public void setTalktousChatNowLink(String talktousChatNowLink) {
		this.talktousChatNowLink = talktousChatNowLink;
	}
	public String getTalktousChatNowText() {
		return talktousChatNowText;
	}
	public void setTalktousChatNowText(String talktousChatNowText) {
		this.talktousChatNowText = talktousChatNowText;
	}
	public long getTalktousPhoneNumber() {
		return talktousPhoneNumber;
	}
	public void setTalktousPhoneNumber(long talktousPhoneNumber) {
		this.talktousPhoneNumber = talktousPhoneNumber;
	}
	public String getTalktousTitle() {
		return talktousTitle;
	}
	public void setTalktousTitle(String talktousTitle) {
		this.talktousTitle = talktousTitle;
	}
	public String getTalktousText() {
		return talktousText;
	}
	public void setTalktousText(String talktousText) {
		this.talktousText = talktousText;
	}
}