package com.ibm.commerce.core.models;

import org.apache.sling.api.resource.ResourceResolver;

public interface SystemUserModel {

	public String getServiceUserTitle();

	public String getEcommSystemUserName();

	public String getStepperCombinedMsg();

}