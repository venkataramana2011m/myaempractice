package com.ibm.commerce.core.models;


public interface HeroImage {
    public String getImageSrc();

    public String getClassList();

    public String getHeading();

    public String getTitle();

    public String getButtonLabel();

    public String getButtonLinkTo();
}
