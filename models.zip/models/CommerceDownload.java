package com.ibm.commerce.core.models;

import org.osgi.annotation.versioning.ProviderType;

import com.adobe.cq.wcm.core.components.models.Download;

@ProviderType
public interface CommerceDownload extends Download {

	public Boolean getCheckbox();
	
}