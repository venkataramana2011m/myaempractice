package com.ibm.commerce.core.models;

public interface ECommerceSignupConfigModel {
	public String getEndpoint();
	public String getInstanceid();
	public String getInstancekey();
	public String getApikey();
	public String getApihost();
}
