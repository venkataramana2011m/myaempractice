package com.ibm.commerce.core.models;

public class OktaUserPassword {
	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}