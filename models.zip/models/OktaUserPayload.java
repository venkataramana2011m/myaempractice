package com.ibm.commerce.core.models;

public class OktaUserPayload {
	private OktaUserProfile profile;
	private OktaUserCredentials credentials;
	private String[] groupIds;

	public OktaUserProfile getProfile() {
		return profile;
	}

	public void setProfile(OktaUserProfile profile) {
		this.profile = profile;
	}

	public OktaUserCredentials getCredentials() {
		return credentials;
	}

	public void setCredentials(OktaUserCredentials credentials) {
		this.credentials = credentials;
	}

	public String[] getGroupIds() {
		return groupIds;
	}

	public void setGroupIds(String[] groupIds) {
		this.groupIds = groupIds;
	}
}