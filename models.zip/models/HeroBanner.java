package com.ibm.commerce.core.models;

public interface HeroBanner {
	public String getPretitle();
	public String getTitle();
	public String getDescription();
	public String getAlttext();
	public String getExpfrag();
	public String getId();
	public String getSubtitle();
	public String getFileReference();
	public String getHeight();
	public String getButtons();
	public String getStartcolor();
	public String getStartcolorposition();
	public String getEndcolor();
	public String getEndcolorposition();

}
