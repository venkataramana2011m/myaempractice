package com.ibm.commerce.core.models;


import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Model(adaptables = Resource.class,defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL )
public class LinkStack {
    @Inject
    private String siteUrl;

    @Inject
    private String siteName;

    @Inject
    private String isExternal;

    @Inject
    private String linkText;

    @Inject
    private String destUrl;

    @Inject
    private String isExternal2;

    @Inject
    private String action2;



    @Inject
    private List<LinkStack> sites;


    @Inject
    private List<LinkStack> links;


    public String getSiteUrl() {
        return siteUrl;
    }

    public String getSiteName() {
        return siteName;
    }

    public String getIsExternal() {
        return isExternal;
    }

    public List<LinkStack> getSites() {
        return List.copyOf(sites);
    }

    public String getLinkText(){ return linkText;}

    public String getDestUrl() {
        return destUrl;
    }

    public String getIsExternal2() {
        return isExternal2;
    }

    public String getAction2() {
        return action2;
    }

    public List<LinkStack> getLinks() {
        return List.copyOf(links);
    }
}
