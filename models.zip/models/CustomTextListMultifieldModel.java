package com.ibm.commerce.core.models;

public interface CustomTextListMultifieldModel {
	 	public String getDestinationURL();
	    public String getExternalLink();
	    public String getListTitle();
}
