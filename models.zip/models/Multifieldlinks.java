package com.ibm.commerce.core.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import lombok.Getter;

@Model(
        adaptables = Resource.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class Multifieldlinks {

	@Inject
	@Getter
	public String fileReference;
	
	@Inject
	@Getter
	public String titleText;
	
	
	@Inject
	@Getter
	public String titleDescription;
}