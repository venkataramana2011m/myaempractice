package com.ibm.commerce.core.models;

public interface BackToTopModel {

    String getButtonType();

    String getButtonText();

    String getTextWithIcon();

    String getIcon();

    String getButtonPosition();

    String getScreenSize();

    boolean getButtonSticky();
}