package com.ibm.commerce.core.models;

public interface VideoModel {
	public String getAccountID();
    public String getPlayerID();
    public String getVideoID();
    public String getVideoIframeLang();
    public String getVideoIframeTitle();
    public String getVideoType();
    public String getVideoUrl();
}
