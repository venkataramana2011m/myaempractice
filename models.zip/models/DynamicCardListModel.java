package com.ibm.commerce.core.models;

public interface DynamicCardListModel{	

    String getCardListType();

    String getCardListDefaultImage();

    int getCardListCount();

    String getPageTitle();

	String getPagePath();
    
}