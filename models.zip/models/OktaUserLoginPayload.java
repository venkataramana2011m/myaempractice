package com.ibm.commerce.core.models;

public class OktaUserLoginPayload {
	private String username;
	private String password;
	private OktaUserOptions options;
	
	public OktaUserOptions getOptions() {
		return options;
	}

	public void setOptions(OktaUserOptions options) {
		this.options = options;
	}

	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
}