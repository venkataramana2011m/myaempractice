package com.ibm.commerce.core.models;
import java.util.*;

public interface CustomTextListModel {
     public String getHeaderTitle() ;

        public String getListType() ;

        public String getTextBelowList();

        public String getTextIsRich();

        public String getTitle();

        public List<CustomTextListMultifieldModel> getTextList();

        public String getTextAboveList();
}
