# GraphQL Sample 
This repository enables an AEM instance to be GraphQL ready.

## Project Structure
The project has following sub-projects.

### all
A resulting content package which includes all built artifacts.

### config
The config sub-project is to include user-defined OSGi configurations.

### content
The content package which includes a global GraphQL endpoint `/content/cq:graphql/global/endpoint` 

### repository-structure
Helper package to serve immutable content (config)

### dispatcher
The dispatcher sub-project contains some additional configurations, in particular:
- [aem-headless.vhost](dispatcher/src/conf.d/available_vhosts/aem-headless.vhost)
- [rewrite.rules](dispatcher/src/conf.d/rewrites/rewrite.rules)
- [aem-headless.farm](dispatcher/src/conf.dispatcher.d/available_farms/aem-headless.farm)
- [filters.any](dispatcher/src/conf.dispatcher.d/filters/filters.any)
- [rules.any](dispatcher/src/conf.dispatcher.d/cache/rules.any)
- [clientheaders.any](dispatcher/src/conf.dispatcher.d/clientheaders/clientheaders.any)

## How to build/deploy for local AEM instance

#### Before you start

When using SDK Quickstart from [AEM as a Cloud Service downloads](https://experience.adobe.com/#/downloads/content/software-distribution/en/aemcloud.html) use
    `AEM SDK v2021.3.5026.20210309T210727Z-210225` 
or more recent version.

To build all the modules run in the project root directory the following command with Maven 3:

    mvn clean install

If you have a running AEM instance you can build and package the whole project and deploy into AEM with:

    mvn clean install -PautoInstallPackage

Depending on your maven configuration, you may find it helpful to force the resolution of the Adobe public repo with:

    mvn clean install -PautoInstallPackage -Padobe-public

Or to deploy it to a publish instance, run:

    mvn clean install -PautoInstallPackagePublish

Or alternatively:

    mvn clean install -PautoInstallPackage -Daem.port=4503

## How to deploy on a AEM Skyline instance
Use or integrate the sub-projects in git repository of your AEM Skyline program, and deploy through the program pipeline execution.

## Endpoint
The AEM Headless endpoints exposed by this project :
- Physical endpoint: `http(s):/host:port/content/_cq_graphql/global/endpoint.json`
- Vanity URL: `http(s):/host:port/content/graphql/global/endpoint.json`
    - Note that the vanity URL does not include the JCR namespace.

