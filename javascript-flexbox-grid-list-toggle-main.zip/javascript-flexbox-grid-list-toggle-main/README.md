## Create a Flexbox Grid List Toggle in Plain JavaScript

This is the code for an article I wrote about creating a grid to list toggle using Flexbox in plain JavaScript.


## Screenshots

Here is the Google Logo we will create:

![JavaScript Grid to List toggle using Flexbox](https://res.cloudinary.com/ratracegrad/image/upload/v1672606619/gridList_tyuymu.gif)

## Read the article

You can [read the article here]( https://www.jenniferbland.com/flexbox-grid-to-…using-javascript/).