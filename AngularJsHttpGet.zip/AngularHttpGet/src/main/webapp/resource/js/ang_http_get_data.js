/* 
 * Description - Angular Script for reading the data from the web-server!
 * Created By - Yatin Batra  
 * */

var app = angular.module("app", []);

app.controller("ctrl", ['$scope', '$http', function($scope, $http) {

	$scope.sortType = 'name'; 		// Set the default sort type
	$scope.sortOrder  = false; 		// Set the default sort order	
	$scope.state  = false;				// Set the default error message state

	$scope.json_data = null; 			// Set the default planet_list

	$scope.getData = function() {
		$http({			
			method: "GET",
			url: 'resource/config/data.json'
		}).then(function(response) {
			$scope.json_data = response.data;
			console.log("Success -> " + response.data);
		}, function(response) {
			$scope.state  = true;
			console.log("Failure");
		});
	};
}]);