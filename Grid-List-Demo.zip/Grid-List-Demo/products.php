{
	"productList": [
	   {
		   "name": "Star Dome",
		   "type": "Tents",
		   "line": "Camping Equipment",
		   "country": "United States",
		   "img": "images/stardome.jpg"
	   },
	   {
		   "name": "Hibernator Lite",
		   "type": "Sleeping Bags",
		   "line": "Camping Equipment",
		   "country": "United States",
		   "img": "images/hibernator.jpg"
	   },
	   {
		   "name": "Husky Rope 50",
		   "type": "Rope",
		   "line": "Mountaineering Equipment",
		   "country": "United States",
		   "img": "images/husky50.jpg"
	   },
	   {
		   "name": "Hailstorm Steel Irons",
		   "type": "Irons",
		   "line": "Golf Equipment",
		   "country": "United States",
		   "img": "images/Hailstorm.jpg"
	   },
	   {
		   "name": "TrailChef Water Bag",
		   "type": "Cooking Gear",
		   "line": "Camping Equipment",
		   "country": "Canada",
		   "img": "images/TrailChef.jpg"
	   },
	   {
		   "name": "EverGlow Butane",
		   "type": "Lanterns",
		   "line": "Camping Equipment",
		   "country": "Canada",
		   "img": "images/EverGlow.jpg"
	   },
	   {
		   "name": "Mountain Man Analog",
		   "type": "Watches",
		   "line": "Personal Accessories",
		   "country": "Canada",
		   "img": "images/Mountain.jpg"
	   },	   
	   {
		   "name": "Bella",
		   "type": "Eyewear",
		   "line": "Personal Accessories",
		   "country": "Canada",
		   "img": "images/bella.jpg"
	   },
	   {
		   "name": "Sun Shelter 30",
		   "type": "Sunscreen",
		   "line": "Outdoor Protection",
		   "country": "Japan",
		   "img": "images/Sun.jpg"
	   },
	   {
		   "name": "Compact Relief Kit",
		   "type": "First Aid",
		   "line": "Outdoor Protection",
		   "country": "Japan",
		   "img": "images/compact.jpg"
	   },
	   {
		   "name": "Trail Master",
		   "type": "Navigation",
		   "line": "Personal Accessories",
		   "country": "Australia",
		   "img": "images/trail.gif"
	   },
	   {
		   "name": "Double Edge",
		   "type": "Knives",
		   "line": "Personal Accessories",
		   "country": "France",
		   "img": "images/knife.jpg"
	   }
	   
	]
}